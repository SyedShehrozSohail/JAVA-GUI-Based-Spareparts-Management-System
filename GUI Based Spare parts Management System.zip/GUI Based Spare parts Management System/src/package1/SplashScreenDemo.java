/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package package1;
import java.awt.*;
import javax.swing.*;

/**
 *
 * @author Syed Shehroz Sohail
 */
 
public class SplashScreenDemo {
    JFrame frame;
    JLabel text=new JLabel("SSS Traders");
    JProgressBar progressBar=new JProgressBar();
    JLabel message=new JLabel();
    public SplashScreenDemo()
    {
        initSplashScreen();
    }
    
    public void initSplashScreen()
    {
        frame=new JFrame();
        frame.getContentPane().setLayout(null);
        frame.setUndecorated(true);//aisa krnay se oper wala gaib ho jaye ga
        frame.setSize(560,380);
        frame.setLocation(380, 200);
        frame.getContentPane().setBackground(Color.BLACK);
        frame.setVisible(true);

        text.setFont(new Font("arial",Font.CENTER_BASELINE,30));
        text.setBounds(170,220,600,40);
        text.setForeground(Color.RED);
        frame.add(text);


        progressBar.setBounds(100,280,400,30);
        progressBar.setBorderPainted(true);
        progressBar.setStringPainted(true);
        progressBar.setBackground(Color.WHITE);
        progressBar.setForeground(Color.BLUE);
        progressBar.setValue(0);
        frame.add(progressBar);
        
        message.setBounds(250,320,200,40);
        message.setForeground(Color.BLUE);
        message.setFont(new Font("arial",Font.BOLD,15));
        frame.add(message);
        
        runningPBar();
    }  
   
  
    public void runningPBar(){
        int i=0;
 
        while( i<=100)
        {
            try{
                Thread.sleep(50);
                progressBar.setValue(i);
                message.setText("LOADING "+Integer.toString(i)+"%");
                i++;
                if(i==100)
                {
                    frame.dispose();
                    new LoginGUI();
                }
            }catch(Exception e){
                e.printStackTrace();
            }
        }
    }
}