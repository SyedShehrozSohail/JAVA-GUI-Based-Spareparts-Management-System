/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package package1;

import java.sql.SQLException;

/**
 *
 * @author Syed Shehroz Sohail
 */
public class Driver {
      public static void main(String args[])  throws SQLException , ClassNotFoundException
    {
        System.out.println("Hello from the main");
        //  AddProductGUI ap= new AddProductGUI();  
            //new FirstClass();
            //MainGUI mg=new MainGUI();
            //SplashScreenDemo sp= new SplashScreenDemo();
            new  AddStockGUI();
             //new SaleProductGUI();
    }
}
