/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package package1;

import com.mysql.jdbc.Statement;
import java.awt.FlowLayout;
import java.sql.SQLException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

/**
 *
 * @author Syed Shehroz Sohail
 */
public class DeleteProductGUI {
    JFrame frame;
    JButton btnDelete,home;
    JLabel jl;
    JTextField icodedel;
    public DeleteProductGUI()
    {
        initDeleteProductGUI();
    }
    public void initDeleteProductGUI()
    {
            frame=new JFrame("Delete Product");
            FlowLayout fl= new FlowLayout();
            jl= new JLabel("Enter the itemcode of the product: ");
            frame.setLayout(fl);
            icodedel=new JTextField(10);
            btnDelete = new JButton("Delete");
            home = new JButton("Homepage");
            frame.add(jl);
            frame.add(icodedel);
            frame.add(btnDelete);
            frame.add(home);
            frame.setVisible(true);
            
             btnDelete.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new DeleteProductDAO(icodedel.getText());
                frame.setVisible(false);
                new ViewProductGUI();
                
            }
        });
             home.addActionListener(new ActionListener(){
              public void actionPerformed(ActionEvent e) {
                  new MainGUI();
                  frame.setVisible(false);
              }
           });
            frame.setResizable(false);
            frame.setSize(300, 200);
            frame.setLocation(500, 100);
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);            
    }
    
}
