/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package package1;

import com.mysql.jdbc.Statement;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.NumberFormat;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.AbstractButton;
import javax.swing.JButton;
import javax.swing.JFormattedTextField;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.text.NumberFormatter;

/**
 *
 * @author Syed Shehroz Sohail
 */
public class AddStockGUI{
    JPanel p1,p2;
 
    JButton home;
        JFrame frame;
        JButton submitButton;
        JTextField itemcodetf, 
                quantitytf;
                
        JLabel itemcodelbl, 
                quantitylbl;
        NumberFormat format = NumberFormat.getInstance();
        NumberFormatter formatter = new NumberFormatter(format);
   
        public AddStockGUI()
        {
            initASGUI();
        }
        public void initASGUI() 
        {
            frame=new JFrame("SSSS Traders Add Stock GUI");
            FlowLayout fl= new FlowLayout();
            frame.setLayout(fl);
            itemcodetf=new JTextField(20);
            home= new JButton("Homepage");
            itemcodelbl=new JLabel("Item Code");
           
             formatter.setValueClass(Integer.class);
             formatter.setMinimum(0);
             formatter.setMaximum(9999);
             formatter.setAllowsInvalid(false);
             formatter.setCommitsOnValidEdit(true);

             quantitytf=new JFormattedTextField(formatter);
             quantitylbl=new JLabel("Quantity");
             submitButton =new JButton("Add Stock");
             p1= new JPanel(new GridLayout(9, 2));
             p2= new JPanel(new GridLayout(1,2));
             frame.add(p1, BorderLayout.CENTER);  
             frame.add(p2, BorderLayout.SOUTH);  
            
            p1.add(itemcodelbl);
            p1.add(itemcodetf);

            p1.add(quantitylbl);
            p1.add(quantitytf);
            
            String s1=itemcodetf.getText().toString();
            String s3=quantitytf.getText().toString();
            
           
            p2.add(submitButton);
            p2.add(home);
           submitButton.addActionListener(new ActionListener(){
              public void actionPerformed(ActionEvent e) {
                  if(itemcodetf.getText().equals("") || quantitytf.getText().equals(""))
                  {
                      JOptionPane.showInternalMessageDialog(null, "Empty Fields! ", "Error in processing", JOptionPane.PLAIN_MESSAGE); 
                  }
                  
                  else
                  {
                      try{
                        new AddStockDAO(itemcodetf.getText(),quantitytf.getText());
                        frame.setVisible(false);
                        new ViewProductGUI();   
                      }
                      catch(Exception ex)
                      {
                          ex.printStackTrace();
                      }
                       
                  }
              }
           });
           home.addActionListener(new ActionListener(){
              public void actionPerformed(ActionEvent e) {
                  new MainGUI();
                  frame.setVisible(false);
              }
           });
            frame.setVisible(true);
            frame.setResizable(false);
            frame.setSize(400, 300);
           // frame.setLocation(500, 200);
            frame.setLocationRelativeTo(null);
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        }
}
