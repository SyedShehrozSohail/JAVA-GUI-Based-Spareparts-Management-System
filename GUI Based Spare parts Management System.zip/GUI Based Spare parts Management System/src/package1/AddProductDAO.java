/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package package1;

import com.mysql.jdbc.ResultSetMetaData;
import com.mysql.jdbc.Statement;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author Syed Shehroz Sohail
 */
public class AddProductDAO{
    Connection connection;
    PreparedStatement preparedStatement;
    ResultSet resultSet;
    Statement statement;
  
    public AddProductDAO(String s1,String s2,String s3,String s4,String s5,String s6,String s7,String s8,String s9)
    {
        String preQueryStatement ="select * from spareparts where itemcode=?";
        String ss3= s3.replaceAll(",", "");
        String ss6= s6.replaceAll(",", "");
        String ss7= s7.replaceAll(",", "");
         
      String sql = "insert into spareparts (itemcode, partname, quantity, company, warranty," +
                                        " salesprice, purchaseprice, category, description)" +
                " values (?, ?, ?, ?, ?, ?, ?, ?, ?)";
    try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/mydb", "root", "")) {
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            preparedStatement = conn.prepareStatement(preQueryStatement);
            preparedStatement.setString(1,s1);            
            ResultSet rs = preparedStatement.executeQuery();
        if(!rs.next())
        {
            stmt.setString(1, s1);
            stmt.setString(2, s2);
            stmt.setString(3, ss3);
            stmt.setString(4, s4);
            stmt.setString(5, s5);
            stmt.setString(6, ss6);
            stmt.setString(7, ss7);
            stmt.setString(8, s8);
            stmt.setString(9, s9);
            stmt.executeUpdate();
            JOptionPane.showInternalMessageDialog(null, "Added Succesfully", "Item Added", JOptionPane.PLAIN_MESSAGE);

        }
        else
        {
            JOptionPane.showMessageDialog(null, "Item already exists","Itemcode of multiple items cannot be same",0);
        }
            
        }
    }             catch (SQLException ex) {   
                      Logger.getLogger(AddProductGUI.class.getName()).log(Level.SEVERE, null, ex);
                  }   
    } 
}
