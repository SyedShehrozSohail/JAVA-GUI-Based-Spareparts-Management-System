/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package package1;

import com.mysql.jdbc.Statement;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.AbstractButton;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.*;
import java.awt.*;
import java.text.NumberFormat;
import javax.swing.text.NumberFormatter;
/**
 *
 * @author Syed Shehroz Sohail
 */
public class FirstClass{
    JPanel p1,p2;
 
    JButton home;
        JFrame frame;
        JButton submitButton;
        JTextField itemcodetf, partnametf, 
                quantitytf, companytf, 
                warrantytf, salespricetf, 
                purchasepricetf, categorytf, 
                descriptiontf;
        JLabel itemcodelbl, partnamelbl,
                quantitylbl, companylbl,
                warrantylbl, salespricelbl,
                purchasepricelbl, categorylbl,
                descriptionlbl;
        NumberFormat format = NumberFormat.getInstance();
    NumberFormatter formatter = new NumberFormatter(format);
  
        
        
        public FirstClass()
        {
            initAPGUI();
        }
        public void initAPGUI() 
        {
            frame=new JFrame("SSSS Traders Add Product GUI");
            FlowLayout fl= new FlowLayout();
            frame.setLayout(fl);
            itemcodetf=new JTextField(20);
            home= new JButton("Homepage");
            itemcodelbl=new JLabel("Item Code");
            partnametf=new JTextField(20);
            partnamelbl=new JLabel("Part Name");
            quantitytf=new JTextField(20);
            quantitylbl=new JLabel("  Quantity");
            companytf=new JTextField(20);
            companylbl=new JLabel("Company");
            warrantytf=new JTextField(20);
            warrantylbl=new JLabel("Warranty");
            salespricetf=new JTextField(20);
            salespricelbl=new JLabel("Sales Price");
            purchasepricetf=new JTextField(20);
            purchasepricelbl=new JLabel("Purchase Price");
            categorytf=new JTextField(20);
            categorylbl=new JLabel("Category");
            descriptiontf=new JTextField(20);
            descriptionlbl=new JLabel("Description");
            submitButton =new JButton("Submit");
             p1= new JPanel(new GridLayout(9, 2));
             p2= new JPanel(new GridLayout(1,2));
        
         formatter.setValueClass(Integer.class);
         formatter.setMinimum(0);
         formatter.setMaximum(Integer.MAX_VALUE);
         formatter.setAllowsInvalid(false);
    // If you want the value to be committed on each keystroke instead of focus lost
        formatter.setCommitsOnValidEdit(true);

    // getValue() always returns something valid
           // System.out.println(field.getValue());
             
             
      //  frame.add(p0, BorderLayout.NORTH);
           submitButton.addActionListener(new ActionListener(){
              public void actionPerformed(ActionEvent e) {
                new AddProductDAO(itemcodetf.getText().toString(),partnametf.getText().toString(),quantitytf.getText().toString(),companytf.getText().toString(),warrantytf.getText().toString(),salespricetf.getText().toString(),purchasepricetf.getText().toString(),categorytf.getText().toString(),descriptiontf.getText().toString());
}
           });
           home.addActionListener(new ActionListener(){
              public void actionPerformed(ActionEvent e) {
                  new MainGUI();
                  frame.setVisible(false);
              }
           });
            frame.setVisible(true);
            frame.setResizable(false);
            frame.setSize(600, 300);
            frame.setLocation(500, 100);
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        }
}
