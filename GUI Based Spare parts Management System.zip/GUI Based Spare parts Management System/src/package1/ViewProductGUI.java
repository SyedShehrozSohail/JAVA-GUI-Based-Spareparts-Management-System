/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package package1;
import javax.swing.*;
import com.mysql.jdbc.Util;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Vector;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Syed Shehroz Sohail
 */

public class ViewProductGUI  {
    JFrame frame;
    JPanel p1,p2;
    DAOmain d= new DAOmain();
    JLabel jl;
    JTable jtable;
    JButton home;
    public ViewProductGUI()
    {
        initVPGUI();
    }
    public void initVPGUI() 
    {
        frame=new JFrame("SSSS Traders View Product GUI");
        FlowLayout fl= new FlowLayout();
        frame.setLayout(fl);
        home = new JButton("Homepage");
        Vector columnNames = new Vector();
        columnNames.addElement("Item Code");
        columnNames.addElement("Part Name");
        columnNames.addElement("Quantity");
        columnNames.addElement("Company");
        columnNames.addElement("Warranty");
        columnNames.addElement("Sales Price");
        columnNames.addElement("Purchase Price");
        columnNames.addElement("Category");
        columnNames.addElement("Description");
        columnNames.addElement("Profit");
        jtable=new JTable(d.data,columnNames);
        jtable.setAutoResizeMode( JTable.AUTO_RESIZE_OFF );
        frame.setSize(500, 600);
        JScrollPane sp = new JScrollPane(jtable);
        
        frame.add(sp);
        frame.add(home);
        home.addActionListener(new ActionListener(){
              public void actionPerformed(ActionEvent e) {
                  new MainGUI();
                  frame.setVisible(false);
              }
           });
        frame.setLocation(500, 100);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }
}