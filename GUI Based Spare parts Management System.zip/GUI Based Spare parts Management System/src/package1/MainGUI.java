/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package package1;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

/**
 *
 * @author Syed Shehroz Sohail
 */
public class MainGUI {
    JFrame frame;
    JLabel label;
    JButton addBtn, deleteBtn, updateBtn, addStockBtn, saleStockBtn, viewStockBtn;
    JPanel p0,p1, p2; 
    public MainGUI()
    {
        initMainGUI();
    }
    public void initMainGUI()
    {
        frame= new JFrame("Homepage");
        FlowLayout fl= new FlowLayout();
        BorderLayout bl=new BorderLayout();
        frame.setLayout(bl);
        addBtn= new JButton("Add Product");
        deleteBtn= new JButton("Delete Product");
        updateBtn= new JButton("Update Product");
        addStockBtn= new JButton("Add Stock");
        saleStockBtn= new JButton("Sale Product");
        viewStockBtn= new JButton("View Stock");
        label= new JLabel("Welcome");
        p1= new JPanel(new GridLayout(3, 2));
        p2= new JPanel(new FlowLayout());
        p0= new JPanel(new FlowLayout());
        
       
        frame.add(p0, BorderLayout.NORTH);
        frame.add(p1, BorderLayout.CENTER);  
        frame.add(p2, BorderLayout.SOUTH);  
        
        p0.add(label);
        p1.add(addBtn);
        p1.add(deleteBtn);
        p1.add(updateBtn);
        p1.add(addStockBtn);
        p1.add(saleStockBtn);
        p1.add(viewStockBtn);
        frame.setVisible(true);
       
        deleteBtn.addActionListener(new ActionListener(){
              public void actionPerformed(ActionEvent e) {
                   new DeleteProductGUI();
                   frame.setVisible(false);

              }
           });
        addBtn.addActionListener(new ActionListener(){
              public void actionPerformed(ActionEvent e) {
                   new AddProductGUI();
                   frame.setVisible(false);

              }
           });
        viewStockBtn.addActionListener(new ActionListener(){
              public void actionPerformed(ActionEvent e) {
                   new ViewProductGUI();
                   frame.setVisible(false);

              }
           });
         updateBtn.addActionListener(new ActionListener(){
              public void actionPerformed(ActionEvent e) {
                   new UpdateProductGUI();
                   frame.setVisible(false);

              }
           });
         addStockBtn.addActionListener(new ActionListener(){
              public void actionPerformed(ActionEvent e) {
                   new AddStockGUI();
                   frame.setVisible(false);

              }
           });
         saleStockBtn.addActionListener(new ActionListener(){
              public void actionPerformed(ActionEvent e) {
                   new SaleProductGUI();
                   frame.setVisible(false);

              }
           });
        frame.setResizable(false);
        frame.setSize(300, 175);
        frame.setLocation(500, 100);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

    }
    
    
}
