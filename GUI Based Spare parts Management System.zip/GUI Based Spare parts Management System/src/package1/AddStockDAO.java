/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package package1;

import com.mysql.jdbc.ResultSetMetaData;
import com.mysql.jdbc.Statement;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author Syed Shehroz Sohail
 */
public class AddStockDAO{
    Connection connection;
    PreparedStatement preparedStatement;
    ResultSet resultSet;
    Statement statement;
          String preQueryStatement ="select * from spareparts where itemcode=?";
    
    public AddStockDAO(String s1,String s2) throws SQLException
    {
        String ss2= s2.replaceAll(",", "");
        int num=Integer.parseInt(ss2);
        String preQueryStatement ="select * from spareparts where itemcode=?";
        String sql = "UPDATE spareparts SET quantity = cast(cast(quantity as integer)+ ? as char(20)) "+
            "WHERE  itemcode = ?";

        try {
                connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/mydb", "root", "");  
                preparedStatement = connection.prepareStatement(preQueryStatement);
                preparedStatement.setString(1,s1);            
                ResultSet rs = preparedStatement.executeQuery();
            if(rs.next())
            {
                preparedStatement = connection.prepareStatement(sql);
                preparedStatement.setInt(1, num);
                preparedStatement.setString(2, s1);
                preparedStatement.executeUpdate();   
                JOptionPane.showInternalMessageDialog(null, "Stock Added Succesfully", "Quantity Added ", JOptionPane.PLAIN_MESSAGE);

            }
            else
            {
                JOptionPane.showInternalMessageDialog(null, "Item does not exist in DB", "Cannot Add Quantity", 0);

            }
            
             }
        
            catch (NumberFormatException e) {
                   System.out.println("Exception Found");
            }
            
} 
}
