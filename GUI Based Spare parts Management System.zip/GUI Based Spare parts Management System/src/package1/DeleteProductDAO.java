/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package package1;

import com.mysql.jdbc.Statement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author Syed Shehroz Sohail
 */
public class DeleteProductDAO {
    Connection connection;
    PreparedStatement preparedStatement;
    ResultSet resultSet;
    Statement statement;
    public DeleteProductDAO(String s1)
    {
                String preQueryStatement ="select * from spareparts where itemcode=?";

                try {
                    Class.forName("com.mysql.jdbc.Driver");
                    connection= DriverManager.getConnection("jdbc:mysql://localhost:3306/mydb","root","");
                    preparedStatement = connection.prepareStatement(preQueryStatement);
                    preparedStatement.setString(1,s1);            
                    ResultSet rs = preparedStatement.executeQuery();
                    if(rs.next())
                    {
                         preparedStatement=connection.prepareStatement("delete from spareparts where itemcode=?");
                         preparedStatement.setString(1, s1);
                         preparedStatement.execute();      
                         JOptionPane.showInternalMessageDialog(null, "Deleted Succesfully", "Item Deleted", JOptionPane.PLAIN_MESSAGE);
                    }
                    else
                    {
                         JOptionPane.showInternalMessageDialog(null, "Item does not exist", "Item not found", 0);
                        
                    }
                   
                } 
                catch (SQLException e1) {
                    e1.printStackTrace();
                } catch (ClassNotFoundException ex) {
                    Logger.getLogger(DeleteProductGUI.class.getName()).log(Level.SEVERE, null, ex);
                }

            }

}

    
    

