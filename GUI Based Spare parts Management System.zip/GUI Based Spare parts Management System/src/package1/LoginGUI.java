/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package package1;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

/**
 *
 * @author Syed Shehroz Sohail
 */
public class LoginGUI {
    JPasswordField jpassword;
    JFrame frame;
    JButton login;
    JTextField nametf, passwordtf;
    JLabel namelbl, passwordlbl;
    public LoginGUI()
    {
        initLoginGUI();
    }
    public void initLoginGUI()
    {
        frame= new JFrame("Login");
        FlowLayout fl= new FlowLayout();
        BorderLayout bl= new BorderLayout();
        GridLayout gl = new GridLayout(3,2);
        nametf= new JTextField(20);
        passwordtf= new JTextField(18);
        jpassword= new JPasswordField("",18);
        login= new JButton("Login");
        
        namelbl= new JLabel("Name:");
        passwordlbl= new  JLabel("Password:");
        frame.setLayout(fl);
        frame.setVisible(true);
        frame.add(namelbl);
        frame.add(nametf);
        frame.add(passwordlbl);
//        frame.add(passwordtf);
        frame.add(jpassword);
        frame.add(login);
         login.addActionListener(new ActionListener(){
              public void actionPerformed(ActionEvent e) {
                  if(nametf.getText().equals("Shehroz") && jpassword.getText().equals("12345"))
                  {
                      new MainGUI();
                      frame.setVisible(false);     
                  }
                  else
                  {
                      JOptionPane.showMessageDialog(null, "Incorrect Username or Password","Incorrect Credentials",JOptionPane.PLAIN_MESSAGE);
                  }
                 
              }
           });
        
       // frame.getContentPane().setBackground(Color.BLUE);
        frame.setResizable(false);
        frame.setSize(300, 175);
        frame.setLocation(500, 200);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); 
    }
    
}