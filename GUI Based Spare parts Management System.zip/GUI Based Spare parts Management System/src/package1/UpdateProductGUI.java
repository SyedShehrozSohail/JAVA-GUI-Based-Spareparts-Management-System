/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package package1;

import com.mysql.jdbc.Statement;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.NumberFormat;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.AbstractButton;
import javax.swing.JButton;
import javax.swing.JFormattedTextField;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.text.NumberFormatter;

/**
 *
 * @author Syed Shehroz Sohail
 */
public class UpdateProductGUI{
    JPanel p1,p2;
 
    JButton home;
        JFrame frame;
        JButton submitButton;
        JTextField itemcodetf, partnametf, 
                quantitytf, companytf, 
                warrantytf, salespricetf, 
                purchasepricetf, categorytf, 
                descriptiontf;
        JLabel itemcodelbl, partnamelbl,
                quantitylbl, companylbl,
                warrantylbl, salespricelbl,
                purchasepricelbl, categorylbl,
                descriptionlbl;
        NumberFormat format = NumberFormat.getInstance();
        NumberFormatter formatter = new NumberFormatter(format);
           public UpdateProductGUI()
        {
            initUPGUI();
        }
        public void initUPGUI() 
        {
            frame=new JFrame("SSSS Traders UPDATE Product GUI");
            FlowLayout fl= new FlowLayout();
            frame.setLayout(fl);
            itemcodetf=new JTextField(20);
            home= new JButton("Homepage");
            itemcodelbl=new JLabel("Item Code");
            partnametf=new JTextField(20);
            partnamelbl=new JLabel("Part Name");
            
             formatter.setValueClass(Integer.class);
             formatter.setMinimum(0);
             formatter.setMaximum(9999);
             formatter.setAllowsInvalid(false);
             formatter.setCommitsOnValidEdit(true);

            quantitytf=new JFormattedTextField(formatter);
            quantitylbl=new JLabel("  Quantity");
            companytf=new JTextField(20);
            companylbl=new JLabel("Company");
            warrantytf=new JTextField(20);
            warrantylbl=new JLabel("Warranty");
            salespricetf=new JFormattedTextField(formatter);
            salespricelbl=new JLabel("Sales Price");
            purchasepricetf=new JFormattedTextField(formatter);
            purchasepricelbl=new JLabel("Purchase Price");
            categorytf=new JTextField(20);
            categorylbl=new JLabel("Category");
            descriptiontf=new JTextField(20);
            descriptionlbl=new JLabel("Description");
            submitButton =new JButton("Update Product");
             p1= new JPanel(new GridLayout(9, 2));
             p2= new JPanel(new GridLayout(1,2));
        
       
        frame.add(p1, BorderLayout.CENTER);  
        frame.add(p2, BorderLayout.SOUTH);  
            
            p1.add(itemcodelbl);
            p1.add(itemcodetf);

            p1.add(partnamelbl);
            p1.add(partnametf);
            
            p1.add(quantitylbl);
            p1.add(quantitytf);
            
            p1.add(companylbl);
            p1.add(companytf);
            
            p1.add(warrantylbl);
            p1.add(warrantytf);
            
            p1.add(salespricelbl);
            p1.add(salespricetf);
            
            p1.add(purchasepricelbl);
            p1.add(purchasepricetf);
            
            p1.add(categorylbl);
            p1.add(categorytf);
            
            p1.add(descriptionlbl);
            p1.add(descriptiontf);

           
            String s1=itemcodetf.getText().toString();
            String s2=partnametf.getText().toString();
            String s3=quantitytf.getText().toString();
            String s4=companytf.getText().toString();
            String s5=warrantytf.getText().toString();
            String s6=salespricetf.getText().toString();
            String s7=purchasepricetf.getText().toString();
            String s8=categorytf.getText().toString();
            String s9=descriptiontf.getText().toString();
            //String check=partnametf.getText().toString().replaceAll(" ","").equals("");
            String check1=companytf.getText().toString().replaceAll(" ","");
           
           
            p2.add(submitButton);
            p2.add(home);
           submitButton.addActionListener(new ActionListener(){
              public void actionPerformed(ActionEvent e) {
                  if(itemcodetf.getText().equals(""))
                  {
                      JOptionPane.showInternalMessageDialog(null, "Item-Code Invalid or already exists", "Error in processing", JOptionPane.PLAIN_MESSAGE);
                        
                  }
                  else if(salespricetf.getText().trim().isEmpty() || purchasepricetf.getText().trim().isEmpty() || partnametf.getText().trim().isEmpty() || quantitytf.getText().trim().isEmpty() )
                  {
                      JOptionPane.showInternalMessageDialog(null, "Please fill out the mandatory fields", "Error in processing", JOptionPane.PLAIN_MESSAGE);
                      
                  }
                  else if(itemcodetf.getText().length()>20 || companytf.getText().length()>20  || categorytf.getText().length()>20 || descriptiontf.getText().length()>20 || partnametf.getText().length()>20 || warrantytf.getText().length()>20)
                  {
                      JOptionPane.showInternalMessageDialog(null, "Fields too large to save in DB", "Error in processing", JOptionPane.PLAIN_MESSAGE);
                      
                  }
                 
                  else
                  {
                new UpdateProductDAO(itemcodetf.getText(),partnametf.getText(),quantitytf.getText(),companytf.getText(),warrantytf.getText(),salespricetf.getText(),purchasepricetf.getText(),categorytf.getText(),descriptiontf.getText());
                frame.setVisible(false);
                new ViewProductGUI();       
                  }
               
              }
           });
           home.addActionListener(new ActionListener(){
              public void actionPerformed(ActionEvent e) {
                  new MainGUI();
                  frame.setVisible(false);
              }
           });
            frame.setVisible(true);
            frame.setResizable(false);
            frame.setSize(600, 300);
            frame.setLocation(500, 100);
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        }
}
