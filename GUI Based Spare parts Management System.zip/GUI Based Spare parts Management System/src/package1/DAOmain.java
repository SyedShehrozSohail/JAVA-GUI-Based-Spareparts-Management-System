package package1;


import com.mysql.jdbc.ResultSetMetaData;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Syed Shehroz Sohail
 */
public class DAOmain {
     Connection connection;
     PreparedStatement preparedStatement;
     ResultSet resultSet;
     Vector data= new Vector();
    public DAOmain() {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            connection= DriverManager.getConnection("jdbc:mysql://localhost:3306/mydb","root","");
            preparedStatement=connection.prepareStatement("select * from spareparts order by itemcode");

             resultSet=preparedStatement.executeQuery();
             ResultSetMetaData metaData = (ResultSetMetaData) resultSet.getMetaData();
             int columns = metaData.getColumnCount();
             while (resultSet.next()) {
             Vector row = new Vector(columns);
             for (int i = 1; i <= columns; i++)
             {
                row.addElement(resultSet.getObject(i));
             }
             data.addElement(row);       
        }
    }
    catch (Exception ex) {
            Logger.getLogger(DAOmain.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
